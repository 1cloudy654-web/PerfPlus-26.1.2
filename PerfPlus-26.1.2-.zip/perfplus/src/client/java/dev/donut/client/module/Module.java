package dev.donut.client.module;
import java.util.ArrayList;
import java.util.List;
public abstract class Module {
    private final String name;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    protected Module(String name, Category category){ this.name=name; this.category=category; }
    public String getName(){ return name; }
    public Category getCategory(){ return category; }
    public boolean isEnabled(){ return enabled; }
    public List<Setting> getSettings(){ return settings; }
    protected <T extends Setting> T add(T setting){ settings.add(setting); return setting; }
    public void toggle(){ enabled=!enabled; if(enabled) onEnable(); else onDisable(); }
    public void onEnable(){}
    public void onDisable(){}
}
